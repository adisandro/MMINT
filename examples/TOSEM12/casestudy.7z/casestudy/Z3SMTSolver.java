/*
 * Copyright (c) 2012 Marsha Chechik, Alessio Di Sandro, Michalis Famelis,
 * Rick Salay, Vivien Suen.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *    Alessio Di Sandro, Vivien Suen - Implementation.
 */
package edu.toronto.cs.se.modelepedia.randommodel.operator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.eclipse.emf.common.util.EList;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;

import edu.toronto.cs.se.mmtf.MMTFException;
import edu.toronto.cs.se.mmtf.mid.Model;
import edu.toronto.cs.se.mmtf.mid.operator.impl.OperatorExecutableImpl;
import edu.toronto.cs.se.mmtf.mid.trait.MultiModelOperatorUtils;
import edu.toronto.cs.se.modelepedia.randommodel.RandomModelPackage;
import edu.toronto.cs.se.modelepedia.randommodel.operator.Z3SMTSolver.CLibrary.Z3IncResult;

public class Z3SMTSolver extends OperatorExecutableImpl {

	private static final String Z3_LIBRARY_NAME = "z3";
	private static final String OPERATOR_LIBRARY_NAME = "Z3SMTSolver";
	private static final String LIBRARY_PATH = "/usr/lib";
	//private static final String PREVIOUS_OPERATOR_URI = "http://se.cs.toronto.edu/modelepedia/Operator_RandomModelToSMTLIB";
	private static final String PROPERTY_OUT_TIMEMAVO = "timeMAVO";
	private static final String PROPERTY_OUT_TIMECLASSICAL = "timeClassical";
	private static final String PROPERTY_OUT_TIMEMAVOBACKBONE = "timeMAVOBackbone";
	private static final String PROPERTY_OUT_TIMEMAVOALLSAT = "timeMAVOAllsat";
	private static final String PROPERTY_OUT_FLAGS = "flags";
	private static final String PROPERTY_OUT_SPEEDUPCLASSICALMAVO = "speedupClassicalMAVO";
	private static final String PROPERTY_OUT_SPEEDUPMAVOALLSATMAVOBACKBONE = "speedupMAVOAllsatMAVOBackbone";

	public static final String SMTLIB_PREDICATE_START = "(";
	public static final String SMTLIB_PREDICATE_END = ")";
	public static final String SMTLIB_TRUE = " true ";
	public static final String SMTLIB_FALSE = " false ";
	public static final String SMTLIB_ASSERT = SMTLIB_PREDICATE_START + "assert";
	public static final String SMTLIB_AND = SMTLIB_PREDICATE_START + "and";
	public static final String SMTLIB_OR = SMTLIB_PREDICATE_START + "or";
	public static final String SMTLIB_NOT = SMTLIB_PREDICATE_START + "not";

	private static final char Z3_ELEMFUNC_PLACEHOLDER = '!';
	private static final char Z3_ELEMFUNC_BEGIN = '{';
	private static final char Z3_ELEMFUNC_END = '}';
	private static final char Z3_ELEMFUNC_NEWLINE = '\n';
	private static final String Z3_ELEMFUNC_SEPARATOR = " -> ";

	private boolean timeClassicalEnabled;
	private boolean timeMAVOBackboneEnabled;
	private boolean timeMAVOAllsatEnabled;
	private long timeMAVO;
	private long timeClassical;
	private long timeMAVOBackbone;
	private long timeMAVOAllsat;
	private StringBuilder flags;
	private double speedupClassicalMAVO;
	private double speedupMAVOAllsatMAVOBackbone;
	private boolean isMAVOMaybe;
	private int propertyNum;

	public interface CLibrary extends Library {

		CLibrary Z3_INSTANCE = (CLibrary) Native.loadLibrary(Z3_LIBRARY_NAME, CLibrary.class);
		CLibrary OPERATOR_INSTANCE = (CLibrary) Native.loadLibrary(OPERATOR_LIBRARY_NAME, CLibrary.class);

		public class Z3Result extends Structure {

			public int flag;
			public Pointer model;

			@Override
			@SuppressWarnings("rawtypes")
			protected List getFieldOrder() {
				List<String> fields = new ArrayList<String>();
				fields.add("flag");
				fields.add("model");
				return fields;
			}
		}

		public class Z3IncResult extends Structure {

			public int flag;
			public Pointer model;
			public Pointer contextPointer;
			public Pointer solverPointer;
			public Pointer modelPointer;

			@Override
			@SuppressWarnings("rawtypes")
			protected List getFieldOrder() {
				List<String> fields = new ArrayList<String>();
				fields.add("flag");
				fields.add("model");
				fields.add("contextPointer");
				fields.add("solverPointer");
				fields.add("modelPointer");
				return fields;
			}
		}

		int checkSat(String smtEncoding);
		Z3Result checkSatAndGetModel(String smtEncoding);
		void freeResult(Z3Result result);
		Z3IncResult firstCheckSatAndGetModelIncremental(String smtEncoding);
		void checkSatAndGetModelIncremental(Z3IncResult incResult, String smtEncoding, int removeLastAssertion);
		void freeResultIncremental(Z3IncResult incResult);
	}

	private void readProperties(Properties properties) throws Exception {

		timeClassicalEnabled = MultiModelOperatorUtils.getBoolProperty(properties, PROPERTY_OUT_TIMECLASSICAL+MultiModelOperatorUtils.PROPERTY_IN_OUTPUTENABLED_SUFFIX);
		timeMAVOBackboneEnabled = MultiModelOperatorUtils.getBoolProperty(properties, PROPERTY_OUT_TIMEMAVOBACKBONE+MultiModelOperatorUtils.PROPERTY_IN_OUTPUTENABLED_SUFFIX);
		timeMAVOAllsatEnabled = MultiModelOperatorUtils.getBoolProperty(properties, PROPERTY_OUT_TIMEMAVOALLSAT+MultiModelOperatorUtils.PROPERTY_IN_OUTPUTENABLED_SUFFIX);
		propertyNum = MultiModelOperatorUtils.getIntProperty(properties, "property");
	}

	private void initOutput() {

		timeMAVO = -1;
		timeClassical = -1;
		timeMAVOBackbone = -1;
		timeMAVOAllsat = -1;
		flags = new StringBuilder();
		speedupClassicalMAVO = -1;
		speedupMAVOAllsatMAVOBackbone = -1;
		isMAVOMaybe = true;
	}

	private void writeProperties(Properties properties) {

		properties.setProperty(PROPERTY_OUT_TIMEMAVO, String.valueOf(timeMAVO));
		properties.setProperty(PROPERTY_OUT_TIMECLASSICAL, String.valueOf(timeClassical));
		properties.setProperty(PROPERTY_OUT_TIMEMAVOBACKBONE, String.valueOf(timeMAVOBackbone));
		properties.setProperty(PROPERTY_OUT_TIMEMAVOALLSAT, String.valueOf(timeMAVOAllsat));
		properties.setProperty(PROPERTY_OUT_FLAGS, flags.toString());
		properties.setProperty(PROPERTY_OUT_SPEEDUPCLASSICALMAVO, String.valueOf(speedupClassicalMAVO));
		properties.setProperty(PROPERTY_OUT_SPEEDUPMAVOALLSATMAVOBACKBONE, String.valueOf(speedupMAVOAllsatMAVOBackbone));
	}

	private void doMAVOPropertyCheck(String smtlibMavoEncoding, String property) {

		int z3Result;
		String encoding;

		long startTime = System.nanoTime();
		encoding = smtlibMavoEncoding + SMTLIB_ASSERT + property + SMTLIB_PREDICATE_END;
		z3Result = CLibrary.OPERATOR_INSTANCE.checkSat(encoding);
		if (z3Result != 1) {
			isMAVOMaybe = false;
		}
		flags.append(z3Result);
		flags.append(',');
		encoding = smtlibMavoEncoding + SMTLIB_ASSERT + SMTLIB_NOT + property + SMTLIB_PREDICATE_END + SMTLIB_PREDICATE_END;
		z3Result = CLibrary.OPERATOR_INSTANCE.checkSat(encoding);
		if (z3Result != 1) {
			isMAVOMaybe = false;
		}
		flags.append(z3Result);
		flags.append(',');
		long endTime = System.nanoTime();

		timeMAVO = endTime - startTime;
	}

	private void doClassicalPropertyCheck(String smtlibEncoding, String property, HashSet<String> smtlibConcretizations) {

		int z3Result, firstZ3Result = 0;
		String encoding;
		long endTime = 0;

		long startTime = System.nanoTime();
		Iterator<String> iter = smtlibConcretizations.iterator();
		while (iter.hasNext()) {
			String concretization = iter.next();
			encoding = smtlibEncoding + SMTLIB_ASSERT + concretization + SMTLIB_PREDICATE_END + '\n' + SMTLIB_ASSERT + property + SMTLIB_PREDICATE_END;
			z3Result = CLibrary.OPERATOR_INSTANCE.checkSat(encoding);
			flags.append(z3Result);
			flags.append(',');
			if (firstZ3Result == 0) {
				firstZ3Result = z3Result;
			}
			if (z3Result == 0 || (z3Result != firstZ3Result)) {
				endTime = System.nanoTime();
				break;
			}
		}
		if (endTime == 0) {
			endTime = System.nanoTime();
		}

		timeClassical = endTime - startTime;
	}

	private void parseZ3Elements(String z3Model, String z3ElemType, int z3MaxElems, Map<String, Boolean> z3ModelElems, Set<String> z3MayModelElems) {

		int z3ElemsIndex = z3Model.indexOf(Z3_ELEMFUNC_NEWLINE + z3ElemType + Z3_ELEMFUNC_PLACEHOLDER);
		if (z3ElemsIndex != -1) {
			int begin = z3Model.indexOf(Z3_ELEMFUNC_BEGIN, z3ElemsIndex) + 1;
			int end = z3Model.indexOf(Z3_ELEMFUNC_END, z3ElemsIndex);
			String z3ElemsString = z3Model.substring(begin, end).trim();
			int newLine = z3ElemsString.indexOf(Z3_ELEMFUNC_NEWLINE);
			int z3ElemArg;
			boolean z3ModelElemValue;
			while (!z3ElemsString.isEmpty()) {
				String[] z3ElemFunc = z3ElemsString.substring(0, newLine).split(Z3_ELEMFUNC_SEPARATOR);
				z3ElemsString = z3ElemsString.substring(newLine).trim();
				newLine = z3ElemsString.indexOf(Z3_ELEMFUNC_NEWLINE);
				if (newLine == -1) {
					newLine = z3ElemsString.length();
				}
				z3ModelElemValue = Boolean.parseBoolean(z3ElemFunc[1]);
				try {
					z3ElemArg = Integer.parseInt(z3ElemFunc[0]);
				}
				catch(NumberFormatException e) {
					Iterator<String> z3MayModelElemsIter = z3MayModelElems.iterator();
					while (z3MayModelElemsIter.hasNext()) {
						String z3MayModelElem = z3MayModelElemsIter.next();
						if (!z3MayModelElem.startsWith(SMTLIB_PREDICATE_START + z3ElemType) || z3ModelElems.containsKey(z3MayModelElem)) {
							continue;
						}
						z3ModelElems.put(z3MayModelElem, new Boolean(z3ModelElemValue));
					}
					break;
				}
				if (z3ElemArg == 0 || z3ElemArg > z3MaxElems) {
					continue;
				}
				String z3ModelElemName = SMTLIB_PREDICATE_START + z3ElemType + ' ' + z3ElemArg + SMTLIB_PREDICATE_END;
				if (!z3MayModelElems.contains(z3ModelElemName)) {
					continue;
				}
				z3ModelElems.put(z3ModelElemName, new Boolean(z3ModelElemValue));
			}
		}
	}

	private Map<String, Boolean> parseZ3Model(String z3Model, Set<String> z3MayModelElems) {

		// nodes
		Map<String, Boolean> z3ModelElems = new HashMap<String, Boolean>();
		String z3ElemType = RandomModelPackage.eINSTANCE.getNode().getName();
		String z3ElemString = "numberOf" + z3ElemType + 's' + Z3_ELEMFUNC_SEPARATOR;
		int begin = z3Model.indexOf(z3ElemString) + z3ElemString.length();
		int end = z3Model.indexOf(Z3_ELEMFUNC_NEWLINE, begin);
		int z3MaxElems = Integer.parseInt(z3Model.substring(begin, end));
		parseZ3Elements(z3Model, z3ElemType.toLowerCase(), z3MaxElems, z3ModelElems, z3MayModelElems);

		// edges
		z3ElemType = RandomModelPackage.eINSTANCE.getEdge().getName();
		z3ElemString = "numberOf" + z3ElemType + 's' + Z3_ELEMFUNC_SEPARATOR;
		begin = z3Model.indexOf(z3ElemString) + z3ElemString.length();
		end = z3Model.indexOf(Z3_ELEMFUNC_NEWLINE, begin);
		z3MaxElems = Integer.parseInt(z3Model.substring(begin, end));
		parseZ3Elements(z3Model, z3ElemType.toLowerCase(), z3MaxElems, z3ModelElems, z3MayModelElems);

		return z3ModelElems;
	}

	private boolean optimizeBackboneElement(Map<String, Boolean> initialZ3ModelElems, String currentZ3ModelElem, Boolean currentZ3ModelElemValue, Set<String> outOfBackboneZ3ModelElems) {

		Boolean initialZ3ModelElemValue = initialZ3ModelElems.get(currentZ3ModelElem);
		if (initialZ3ModelElemValue == null || (currentZ3ModelElemValue.booleanValue() == initialZ3ModelElemValue.booleanValue())) {
			return false;
		}
		outOfBackboneZ3ModelElems.add(currentZ3ModelElem);

		return true;
	}

	private void optimizeBackboneElements(Map<String, Boolean> initialZ3ModelElems, Map<String, Boolean> currentZ3ModelElems, Set<String> outOfBackboneZ3ModelElems) {

		for (Map.Entry<String, Boolean> currentZ3ModelElemEntry : currentZ3ModelElems.entrySet()) {
			String currentZ3ModelElem = currentZ3ModelElemEntry.getKey();
			Boolean currentZ3ModelElemValue = currentZ3ModelElemEntry.getValue();
			optimizeBackboneElement(initialZ3ModelElems, currentZ3ModelElem, currentZ3ModelElemValue, outOfBackboneZ3ModelElems);
		}
	}

	private void doMAVOBackbonePropertyCheck(String smtlibMavoEncoding, String property, Set<String> z3MayModelElems) throws MMTFException {

		Z3IncResult z3IncResult;
		String encoding;
		Set<String> outOfBackboneZ3ModelElems = new HashSet<String>();

		long startTime = System.nanoTime();
		encoding = smtlibMavoEncoding + SMTLIB_ASSERT + property + SMTLIB_PREDICATE_END;
		z3IncResult = CLibrary.OPERATOR_INSTANCE.firstCheckSatAndGetModelIncremental(encoding);
		flags.append(z3IncResult.flag);
		flags.append(',');
		if (z3IncResult.flag != 1) {
			throw new MMTFException("Property checking for MAVO model was SAT-SAT but the incremental baseline now is UNSAT.");
		}
		Map<String, Boolean> initialZ3ModelElems = parseZ3Model(z3IncResult.model.getString(0), z3MayModelElems);
		Map<String, Boolean> currentZ3ModelElems;
		Iterator<String> z3MayModelElemsIter = z3MayModelElems.iterator();
		while (z3MayModelElemsIter.hasNext()) {
			String z3MayModelElem = z3MayModelElemsIter.next();
			if (outOfBackboneZ3ModelElems.contains(z3MayModelElem)) { // optimization
				continue;
			}
			encoding = SMTLIB_ASSERT + z3MayModelElem + SMTLIB_PREDICATE_END;
			CLibrary.OPERATOR_INSTANCE.checkSatAndGetModelIncremental(z3IncResult, encoding, 1);
			flags.append(z3IncResult.flag);
			flags.append(',');
			if (z3IncResult.flag != 1) { // UNSAT (here z3MayModelElem value should be == to its value in the initial model)
				continue;
			}
			currentZ3ModelElems = parseZ3Model(z3IncResult.model.getString(0), z3MayModelElems);
			optimizeBackboneElements(initialZ3ModelElems, currentZ3ModelElems, outOfBackboneZ3ModelElems);
			initialZ3ModelElems.get(z3MayModelElem);
			if (optimizeBackboneElement(initialZ3ModelElems, z3MayModelElem, currentZ3ModelElems.get(z3MayModelElem), outOfBackboneZ3ModelElems)) { // z3MayModelElem value has already changed
				continue;
			}
			encoding = SMTLIB_ASSERT + SMTLIB_NOT + z3MayModelElem + SMTLIB_PREDICATE_END + SMTLIB_PREDICATE_END;
			CLibrary.OPERATOR_INSTANCE.checkSatAndGetModelIncremental(z3IncResult, encoding, 1);
			flags.append(z3IncResult.flag);
			flags.append(',');
			if (z3IncResult.flag != 1) { // UNSAT
				continue;
			}
			currentZ3ModelElems = parseZ3Model(z3IncResult.model.getString(0), z3MayModelElems);
			optimizeBackboneElements(initialZ3ModelElems, currentZ3ModelElems, outOfBackboneZ3ModelElems);
		}
		CLibrary.OPERATOR_INSTANCE.freeResultIncremental(z3IncResult);
		long endTime = System.nanoTime();

		timeMAVOBackbone = endTime - startTime;
	}

	private HashSet<String> doMAVOAllsatPropertyCheck(String smtlibMavoEncoding, String property, Set<String> z3MayModelElems) {

		Z3IncResult z3IncResult;
		String encoding;
		HashSet<String> smtlibConcretizations = new HashSet<String>();

		long startTime = System.nanoTime();
		encoding = smtlibMavoEncoding + SMTLIB_ASSERT + property + SMTLIB_PREDICATE_END;
		z3IncResult = CLibrary.OPERATOR_INSTANCE.firstCheckSatAndGetModelIncremental(encoding);
		flags.append(z3IncResult.flag);
		flags.append(',');
		while (z3IncResult.flag == 1) {
			StringBuilder concretization = new StringBuilder(SMTLIB_AND);
			Map<String, Boolean> z3ModelElems = parseZ3Model(z3IncResult.model.getString(0), z3MayModelElems);
			StringBuilder encodingBuilder = new StringBuilder();
			encodingBuilder.append(SMTLIB_ASSERT);
			encodingBuilder.append(SMTLIB_OR);
			for (Map.Entry<String, Boolean> z3ModelElem : z3ModelElems.entrySet()) {
				String z3ModelElemName = z3ModelElem.getKey();
				boolean z3ModelElemValue = z3ModelElem.getValue();
				if (z3ModelElemValue) {
					encodingBuilder.append(SMTLIB_NOT);
					encodingBuilder.append(z3ModelElemName);
					encodingBuilder.append(SMTLIB_PREDICATE_END);
					concretization.append(z3ModelElemName);
				}
				else {
					encodingBuilder.append(z3ModelElemName);
					concretization.append(SMTLIB_NOT);
					concretization.append(z3ModelElemName);
					concretization.append(SMTLIB_PREDICATE_END);
				}
			}
			encodingBuilder.append(SMTLIB_PREDICATE_END);
			encodingBuilder.append(SMTLIB_PREDICATE_END);
			CLibrary.OPERATOR_INSTANCE.checkSatAndGetModelIncremental(z3IncResult, encodingBuilder.toString(), 0);
			flags.append(z3IncResult.flag);
			flags.append(',');
			concretization.append(SMTLIB_PREDICATE_END);
			smtlibConcretizations.add(concretization.toString());
		}
		CLibrary.OPERATOR_INSTANCE.freeResultIncremental(z3IncResult);
		long endTime = System.nanoTime();

		timeMAVOAllsat = endTime - startTime;
		return smtlibConcretizations;
	}

	@Override
	public EList<Model> execute(EList<Model> actualParameters) throws Exception {

		Model randommodelModel = actualParameters.get(0);
		Properties inputProperties = MultiModelOperatorUtils.getPropertiesFile(
			this,
			randommodelModel,
			inputSubdir,
			MultiModelOperatorUtils.INPUT_PROPERTIES_SUFFIX
		);
		readProperties(inputProperties);

		// get output from previous operator
//		RandomModelToSMTLIB previousOperator = (previousExecutable == null) ?
//			(RandomModelToSMTLIB) MultiModelTypeRegistry.getOperatorType(PREVIOUS_OPERATOR_URI).getExecutable() :
//			(RandomModelToSMTLIB) previousExecutable;
//		final String smtlibEncoding = previousOperator.getSMTLIBEncoding();
//		final String smtlibMavoEncoding = previousOperator.getSMTLIBMAVOEncoding();
//		HashSet<String> smtlibConcretizations = previousOperator.getSMTLIBConcretizations();
//		final String property = previousOperator.getGroundedProperty();
//		Set<String> z3MayModelElems = new HashSet<String>();
//		for (MAVOElement mayModelObj : previousOperator.getMayModelObjects()) {
//			z3MayModelElems.add(previousOperator.getNamedElementSMTLIBEncoding((NamedElement) mayModelObj));
//		}
			final String smtlibEncoding = "\n;Parameters\n(declare-const numberOfNodes Int)\n(assert (= numberOfNodes 86))\n(declare-const numberOfEdges Int)\n(assert (= numberOfEdges 183))\n\n;Metamodel\n(define-sort Node () Int)\n(define-sort Edge () Int)\n(declare-fun src (Edge) Node)\n(declare-fun tgt (Edge) Node)\n(declare-fun node (Node) bool)\n(declare-fun edge (Edge) bool)\n\n;Symmetry-breaking\n(assert (forall ((k Node)) (=> (node k) (<= k numberOfNodes))))\n(assert (forall ((k Edge)) (=> (edge k) (<= k numberOfEdges))))\n(assert (forall ((k Node)) (=> (node k) (> k 0))))\n(assert (forall ((k Edge)) (=> (edge k) (> k 0))))\n\n(assert (node 1)) \n(assert (node 2)) \n(assert (node 3)) \n(assert (node 4)) \n(assert (node 5)) \n(assert (node 6)) \n(assert (node 7)) \n(assert (node 8)) \n(assert (node 9)) \n(assert (node 10)) \n(assert (node 11)) \n(assert (node 12)) \n(assert (node 13)) \n(assert (node 14)) \n(assert (node 15)) \n(assert (node 16)) \n(assert (node 17)) \n(assert (node 18)) \n(assert (node 19)) \n(assert (node 20)) \n(assert (node 21)) \n(assert (node 22)) \n(assert (node 23)) \n(assert (node 24)) \n(assert (node 25)) \n(assert (node 26)) \n(assert (node 27)) \n(assert (node 28)) \n(assert (node 29)) \n(assert (node 30)) \n(assert (node 31)) \n(assert (node 32)) \n(assert (node 33)) \n(assert (node 34)) \n(assert (node 35)) \n(assert (node 36)) \n(assert (node 37)) \n(assert (node 38)) \n(assert (node 39)) \n(assert (node 40)) \n(assert (node 41)) \n(assert (node 42)) \n(assert (node 43)) \n(assert (node 44)) \n(assert (node 45)) \n(assert (node 46)) \n(assert (node 47)) \n(assert (node 48)) \n(assert (node 49)) \n(assert (node 50)) \n(assert (node 51)) \n(assert (node 52)) \n(assert (node 53)) \n(assert (node 54)) \n(assert (node 55)) \n(assert (node 56)) \n(assert (node 57)) \n(assert (node 58)) \n(assert (node 59)) \n(assert (node 60)) \n(assert (node 61)) \n(assert (node 62)) \n(assert (node 63)) \n(assert (node 64)) \n(assert (node 65)) \n(assert (node 69)) \n(assert (node 70)) \n(assert (node 71)) \n(assert (node 72)) \n(assert (node 73)) \n(assert (node 74)) \n(assert (node 75)) \n\n(assert (edge 1)) \n(assert (= (src 1) 1)) \n(assert (= (tgt 1) 2)) \n \n(assert (edge 2)) \n(assert (= (src 2) 3)) \n(assert (= (tgt 2) 4)) \n \n(assert (edge 3)) \n(assert (= (src 3) 5)) \n(assert (= (tgt 3) 6)) \n \n(assert (edge 4)) \n(assert (= (src 4) 7)) \n(assert (= (tgt 4) 8)) \n \n(assert (edge 5)) \n(assert (= (src 5) 9)) \n(assert (= (tgt 5) 10)) \n \n(assert (edge 6)) \n(assert (= (src 6) 11)) \n(assert (= (tgt 6) 12)) \n \n(assert (edge 7)) \n(assert (= (src 7) 13)) \n(assert (= (tgt 7) 14)) \n \n(assert (edge 8)) \n(assert (= (src 8) 15)) \n(assert (= (tgt 8) 6)) \n \n(assert (edge 9)) \n(assert (= (src 9) 16)) \n(assert (= (tgt 9) 17)) \n \n(assert (edge 10)) \n(assert (= (src 10) 18)) \n(assert (= (tgt 10) 19)) \n \n(assert (edge 11)) \n(assert (= (src 11) 20)) \n(assert (= (tgt 11) 21)) \n \n(assert (edge 12)) \n(assert (= (src 12) 22)) \n(assert (= (tgt 12) 23)) \n \n(assert (edge 13)) \n(assert (= (src 13) 24)) \n(assert (= (tgt 13) 25)) \n \n(assert (edge 14)) \n(assert (= (src 14) 25)) \n(assert (= (tgt 14) 26)) \n \n(assert (edge 15)) \n(assert (= (src 15) 26)) \n(assert (= (tgt 15) 27)) \n \n(assert (edge 16)) \n(assert (= (src 16) 27)) \n(assert (= (tgt 16) 28)) \n \n(assert (edge 17)) \n(assert (= (src 17) 28)) \n(assert (= (tgt 17) 29)) \n \n(assert (edge 18)) \n(assert (= (src 18) 29)) \n(assert (= (tgt 18) 30)) \n \n(assert (edge 19)) \n(assert (= (src 19) 30)) \n(assert (= (tgt 19) 31)) \n \n(assert (edge 20)) \n(assert (= (src 20) 31)) \n(assert (= (tgt 20) 32)) \n \n(assert (edge 21)) \n(assert (= (src 21) 32)) \n(assert (= (tgt 21) 33)) \n \n(assert (edge 22)) \n(assert (= (src 22) 33)) \n(assert (= (tgt 22) 34)) \n \n(assert (edge 23)) \n(assert (= (src 23) 34)) \n(assert (= (tgt 23) 35)) \n \n(assert (edge 24)) \n(assert (= (src 24) 35)) \n(assert (= (tgt 24) 36)) \n \n(assert (edge 25)) \n(assert (= (src 25) 36)) \n(assert (= (tgt 25) 37)) \n \n(assert (edge 26)) \n(assert (= (src 26) 37)) \n(assert (= (tgt 26) 38)) \n \n(assert (edge 27)) \n(assert (= (src 27) 38)) \n(assert (= (tgt 27) 39)) \n \n(assert (edge 28)) \n(assert (= (src 28) 39)) \n(assert (= (tgt 28) 40)) \n \n(assert (edge 29)) \n(assert (= (src 29) 40)) \n(assert (= (tgt 29) 41)) \n \n(assert (edge 30)) \n(assert (= (src 30) 41)) \n(assert (= (tgt 30) 42)) \n \n(assert (edge 31)) \n(assert (= (src 31) 42)) \n(assert (= (tgt 31) 43)) \n \n(assert (edge 32)) \n(assert (= (src 32) 43)) \n(assert (= (tgt 32) 44)) \n \n(assert (edge 33)) \n(assert (= (src 33) 44)) \n(assert (= (tgt 33) 45)) \n \n(assert (edge 34)) \n(assert (= (src 34) 45)) \n(assert (= (tgt 34) 46)) \n \n(assert (edge 35)) \n(assert (= (src 35) 46)) \n(assert (= (tgt 35) 47)) \n \n(assert (edge 36)) \n(assert (= (src 36) 47)) \n(assert (= (tgt 36) 48)) \n \n(assert (edge 37)) \n(assert (= (src 37) 48)) \n(assert (= (tgt 37) 49)) \n \n(assert (edge 38)) \n(assert (= (src 38) 49)) \n(assert (= (tgt 38) 50)) \n \n(assert (edge 39)) \n(assert (= (src 39) 50)) \n(assert (= (tgt 39) 51)) \n \n(assert (edge 40)) \n(assert (= (src 40) 51)) \n(assert (= (tgt 40) 52)) \n \n(assert (edge 41)) \n(assert (= (src 41) 52)) \n(assert (= (tgt 41) 53)) \n \n(assert (edge 42)) \n(assert (= (src 42) 53)) \n(assert (= (tgt 42) 54)) \n \n(assert (edge 43)) \n(assert (= (src 43) 54)) \n(assert (= (tgt 43) 55)) \n \n(assert (edge 44)) \n(assert (= (src 44) 55)) \n(assert (= (tgt 44) 56)) \n \n(assert (edge 45)) \n(assert (= (src 45) 56)) \n(assert (= (tgt 45) 57)) \n \n(assert (edge 46)) \n(assert (= (src 46) 57)) \n(assert (= (tgt 46) 58)) \n \n(assert (edge 47)) \n(assert (= (src 47) 58)) \n(assert (= (tgt 47) 59)) \n \n(assert (edge 48)) \n(assert (= (src 48) 59)) \n(assert (= (tgt 48) 60)) \n \n(assert (edge 49)) \n(assert (= (src 49) 60)) \n(assert (= (tgt 49) 61)) \n \n(assert (edge 50)) \n(assert (= (src 50) 61)) \n(assert (= (tgt 50) 62)) \n \n(assert (edge 51)) \n(assert (= (src 51) 62)) \n(assert (= (tgt 51) 63)) \n \n(assert (edge 52)) \n(assert (= (src 52) 63)) \n(assert (= (tgt 52) 64)) \n \n(assert (edge 53)) \n(assert (= (src 53) 64)) \n(assert (= (tgt 53) 65)) \n \n(assert (edge 58)) \n(assert (= (src 58) 69)) \n(assert (= (tgt 58) 70)) \n \n(assert (edge 59)) \n(assert (= (src 59) 70)) \n(assert (= (tgt 59) 71)) \n \n(assert (edge 60)) \n(assert (= (src 60) 71)) \n(assert (= (tgt 60) 72)) \n \n(assert (edge 61)) \n(assert (= (src 61) 72)) \n(assert (= (tgt 61) 73)) \n \n(assert (edge 62)) \n(assert (= (src 62) 73)) \n(assert (= (tgt 62) 74)) \n \n(assert (edge 63)) \n(assert (= (src 63) 74)) \n(assert (= (tgt 63) 75)) \n \n(assert (edge 64)) \n(assert (= (src 64) 24)) \n(assert (= (tgt 64) 1)) \n \n(assert (edge 65)) \n(assert (= (src 65) 24)) \n(assert (= (tgt 65) 1)) \n \n(assert (edge 66)) \n(assert (= (src 66) 25)) \n(assert (= (tgt 66) 1)) \n \n(assert (edge 67)) \n(assert (= (src 67) 25)) \n(assert (= (tgt 67) 20)) \n \n(assert (edge 68)) \n(assert (= (src 68) 26)) \n(assert (= (tgt 68) 1)) \n \n(assert (edge 69)) \n(assert (= (src 69) 26)) \n(assert (= (tgt 69) 3)) \n \n(assert (edge 70)) \n(assert (= (src 70) 27)) \n(assert (= (tgt 70) 1)) \n \n(assert (edge 71)) \n(assert (= (src 71) 27)) \n(assert (= (tgt 71) 3)) \n \n(assert (edge 72)) \n(assert (= (src 72) 28)) \n(assert (= (tgt 72) 1)) \n \n(assert (edge 73)) \n(assert (= (src 73) 28)) \n(assert (= (tgt 73) 3)) \n \n(assert (edge 74)) \n(assert (= (src 74) 29)) \n(assert (= (tgt 74) 1)) \n \n(assert (edge 75)) \n(assert (= (src 75) 29)) \n(assert (= (tgt 75) 5)) \n \n(assert (edge 76)) \n(assert (= (src 76) 30)) \n(assert (= (tgt 76) 1)) \n \n(assert (edge 77)) \n(assert (= (src 77) 30)) \n(assert (= (tgt 77) 7)) \n \n(assert (edge 78)) \n(assert (= (src 78) 31)) \n(assert (= (tgt 78) 1)) \n \n(assert (edge 79)) \n(assert (= (src 79) 31)) \n(assert (= (tgt 79) 5)) \n \n(assert (edge 80)) \n(assert (= (src 80) 32)) \n(assert (= (tgt 80) 1)) \n \n(assert (edge 81)) \n(assert (= (src 81) 32)) \n(assert (= (tgt 81) 7)) \n \n(assert (edge 82)) \n(assert (= (src 82) 33)) \n(assert (= (tgt 82) 1)) \n \n(assert (edge 83)) \n(assert (= (src 83) 33)) \n(assert (= (tgt 83) 9)) \n \n(assert (edge 84)) \n(assert (= (src 84) 34)) \n(assert (= (tgt 84) 1)) \n \n(assert (edge 85)) \n(assert (= (src 85) 34)) \n(assert (= (tgt 85) 11)) \n \n(assert (edge 86)) \n(assert (= (src 86) 35)) \n(assert (= (tgt 86) 1)) \n \n(assert (edge 87)) \n(assert (= (src 87) 35)) \n(assert (= (tgt 87) 13)) \n \n(assert (edge 88)) \n(assert (= (src 88) 36)) \n(assert (= (tgt 88) 1)) \n \n(assert (edge 89)) \n(assert (= (src 89) 36)) \n(assert (= (tgt 89) 5)) \n \n(assert (edge 90)) \n(assert (= (src 90) 37)) \n(assert (= (tgt 90) 1)) \n \n(assert (edge 91)) \n(assert (= (src 91) 37)) \n(assert (= (tgt 91) 5)) \n \n(assert (edge 92)) \n(assert (= (src 92) 38)) \n(assert (= (tgt 92) 1)) \n \n(assert (edge 93)) \n(assert (= (src 93) 38)) \n(assert (= (tgt 93) 13)) \n \n(assert (edge 94)) \n(assert (= (src 94) 39)) \n(assert (= (tgt 94) 1)) \n \n(assert (edge 95)) \n(assert (= (src 95) 39)) \n(assert (= (tgt 95) 5)) \n \n(assert (edge 96)) \n(assert (= (src 96) 40)) \n(assert (= (tgt 96) 1)) \n \n(assert (edge 97)) \n(assert (= (src 97) 40)) \n(assert (= (tgt 97) 5)) \n \n(assert (edge 98)) \n(assert (= (src 98) 41)) \n(assert (= (tgt 98) 1)) \n \n(assert (edge 99)) \n(assert (= (src 99) 41)) \n(assert (= (tgt 99) 5)) \n \n(assert (edge 100)) \n(assert (= (src 100) 42)) \n(assert (= (tgt 100) 1)) \n \n(assert (edge 101)) \n(assert (= (src 101) 42)) \n(assert (= (tgt 101) 15)) \n \n(assert (edge 102)) \n(assert (= (src 102) 43)) \n(assert (= (tgt 102) 1)) \n \n(assert (edge 103)) \n(assert (= (src 103) 43)) \n(assert (= (tgt 103) 3)) \n \n(assert (edge 104)) \n(assert (= (src 104) 44)) \n(assert (= (tgt 104) 1)) \n \n(assert (edge 105)) \n(assert (= (src 105) 44)) \n(assert (= (tgt 105) 16)) \n \n(assert (edge 106)) \n(assert (= (src 106) 45)) \n(assert (= (tgt 106) 1)) \n \n(assert (edge 107)) \n(assert (= (src 107) 45)) \n(assert (= (tgt 107) 3)) \n \n(assert (edge 108)) \n(assert (= (src 108) 46)) \n(assert (= (tgt 108) 1)) \n \n(assert (edge 109)) \n(assert (= (src 109) 46)) \n(assert (= (tgt 109) 16)) \n \n(assert (edge 110)) \n(assert (= (src 110) 47)) \n(assert (= (tgt 110) 1)) \n \n(assert (edge 111)) \n(assert (= (src 111) 47)) \n(assert (= (tgt 111) 3)) \n \n(assert (edge 112)) \n(assert (= (src 112) 48)) \n(assert (= (tgt 112) 1)) \n \n(assert (edge 113)) \n(assert (= (src 113) 48)) \n(assert (= (tgt 113) 5)) \n \n(assert (edge 114)) \n(assert (= (src 114) 49)) \n(assert (= (tgt 114) 1)) \n \n(assert (edge 115)) \n(assert (= (src 115) 49)) \n(assert (= (tgt 115) 5)) \n \n(assert (edge 116)) \n(assert (= (src 116) 50)) \n(assert (= (tgt 116) 1)) \n \n(assert (edge 117)) \n(assert (= (src 117) 50)) \n(assert (= (tgt 117) 5)) \n \n(assert (edge 118)) \n(assert (= (src 118) 51)) \n(assert (= (tgt 118) 1)) \n \n(assert (edge 119)) \n(assert (= (src 119) 51)) \n(assert (= (tgt 119) 5)) \n \n(assert (edge 120)) \n(assert (= (src 120) 52)) \n(assert (= (tgt 120) 1)) \n \n(assert (edge 121)) \n(assert (= (src 121) 52)) \n(assert (= (tgt 121) 3)) \n \n(assert (edge 122)) \n(assert (= (src 122) 53)) \n(assert (= (tgt 122) 1)) \n \n(assert (edge 123)) \n(assert (= (src 123) 53)) \n(assert (= (tgt 123) 5)) \n \n(assert (edge 124)) \n(assert (= (src 124) 54)) \n(assert (= (tgt 124) 1)) \n \n(assert (edge 125)) \n(assert (= (src 125) 54)) \n(assert (= (tgt 125) 7)) \n \n(assert (edge 126)) \n(assert (= (src 126) 55)) \n(assert (= (tgt 126) 1)) \n \n(assert (edge 127)) \n(assert (= (src 127) 55)) \n(assert (= (tgt 127) 5)) \n \n(assert (edge 128)) \n(assert (= (src 128) 56)) \n(assert (= (tgt 128) 1)) \n \n(assert (edge 129)) \n(assert (= (src 129) 56)) \n(assert (= (tgt 129) 7)) \n \n(assert (edge 130)) \n(assert (= (src 130) 57)) \n(assert (= (tgt 130) 1)) \n \n(assert (edge 131)) \n(assert (= (src 131) 57)) \n(assert (= (tgt 131) 5)) \n \n(assert (edge 132)) \n(assert (= (src 132) 58)) \n(assert (= (tgt 132) 1)) \n \n(assert (edge 133)) \n(assert (= (src 133) 58)) \n(assert (= (tgt 133) 5)) \n \n(assert (edge 134)) \n(assert (= (src 134) 59)) \n(assert (= (tgt 134) 1)) \n \n(assert (edge 135)) \n(assert (= (src 135) 59)) \n(assert (= (tgt 135) 3)) \n \n(assert (edge 136)) \n(assert (= (src 136) 60)) \n(assert (= (tgt 136) 1)) \n \n(assert (edge 137)) \n(assert (= (src 137) 60)) \n(assert (= (tgt 137) 5)) \n \n(assert (edge 138)) \n(assert (= (src 138) 61)) \n(assert (= (tgt 138) 1)) \n \n(assert (edge 139)) \n(assert (= (src 139) 61)) \n(assert (= (tgt 139) 3)) \n \n(assert (edge 140)) \n(assert (= (src 140) 62)) \n(assert (= (tgt 140) 1)) \n \n(assert (edge 141)) \n(assert (= (src 141) 62)) \n(assert (= (tgt 141) 5)) \n \n(assert (edge 142)) \n(assert (= (src 142) 63)) \n(assert (= (tgt 142) 1)) \n \n(assert (edge 143)) \n(assert (= (src 143) 63)) \n(assert (= (tgt 143) 22)) \n \n(assert (edge 144)) \n(assert (= (src 144) 64)) \n(assert (= (tgt 144) 1)) \n \n(assert (edge 145)) \n(assert (= (src 145) 64)) \n(assert (= (tgt 145) 22)) \n \n(assert (edge 146)) \n(assert (= (src 146) 65)) \n(assert (= (tgt 146) 1)) \n \n(assert (edge 147)) \n(assert (= (src 147) 65)) \n(assert (= (tgt 147) 5)) \n \n(assert (edge 170)) \n(assert (= (src 170) 69)) \n(assert (= (tgt 170) 1)) \n \n(assert (edge 171)) \n(assert (= (src 171) 69)) \n(assert (= (tgt 171) 7)) \n \n(assert (edge 172)) \n(assert (= (src 172) 70)) \n(assert (= (tgt 172) 1)) \n \n(assert (edge 173)) \n(assert (= (src 173) 70)) \n(assert (= (tgt 173) 18)) \n \n(assert (edge 174)) \n(assert (= (src 174) 71)) \n(assert (= (tgt 174) 1)) \n \n(assert (edge 175)) \n(assert (= (src 175) 71)) \n(assert (= (tgt 175) 5)) \n \n(assert (edge 176)) \n(assert (= (src 176) 72)) \n(assert (= (tgt 176) 1)) \n \n(assert (edge 177)) \n(assert (= (src 177) 72)) \n(assert (= (tgt 177) 7)) \n \n(assert (edge 178)) \n(assert (= (src 178) 73)) \n(assert (= (tgt 178) 1)) \n \n(assert (edge 179)) \n(assert (= (src 179) 73)) \n(assert (= (tgt 179) 18)) \n \n(assert (edge 180)) \n(assert (= (src 180) 74)) \n(assert (= (tgt 180) 1)) \n \n(assert (edge 181)) \n(assert (= (src 181) 74)) \n(assert (= (tgt 181) 5)) \n \n(assert (edge 182)) \n(assert (= (src 182) 75)) \n(assert (= (tgt 182) 1)) \n \n(assert (edge 183)) \n(assert (= (src 183) 75)) \n(assert (= (tgt 183) 7)) \n \n\n;May Begin\n;(assert (node 66)) \n;(assert (node 67)) \n;(assert (node 68)) \n;(assert (node 76)) \n;(assert (node 77)) \n;(assert (node 78)) \n;(assert (node 79)) \n;(assert (node 80)) \n;(assert (node 81)) \n;(assert (node 82)) \n;(assert (node 83)) \n;(assert (node 84)) \n;(assert (node 85)) \n;(assert (node 86)) \n\n\n;(assert (edge 54)) \n(assert (= (src 54) 65)) \n(assert (= (tgt 54) 66)) \n \n;(assert (edge 55)) \n(assert (= (src 55) 66)) \n(assert (= (tgt 55) 67)) \n \n;(assert (edge 56)) \n(assert (= (src 56) 67)) \n(assert (= (tgt 56) 68)) \n \n;(assert (edge 57)) \n(assert (= (src 57) 68)) \n(assert (= (tgt 57) 69)) \n \n;(assert (edge 148)) \n(assert (= (src 148) 66)) \n(assert (= (tgt 148) 1)) \n \n;(assert (edge 149)) \n(assert (= (src 149) 66)) \n(assert (= (tgt 149) 76)) \n \n;(assert (edge 150)) \n(assert (= (src 150) 67)) \n(assert (= (tgt 150) 1)) \n \n;(assert (edge 151)) \n(assert (= (src 151) 67)) \n(assert (= (tgt 151) 76)) \n \n;(assert (edge 152)) \n(assert (= (src 152) 68)) \n(assert (= (tgt 152) 76)) \n \n;(assert (edge 153)) \n(assert (= (src 153) 68)) \n(assert (= (tgt 153) 7)) \n \n;(assert (edge 154)) \n(assert (= (src 154) 77)) \n(assert (= (tgt 154) 1)) \n \n;(assert (edge 155)) \n(assert (= (src 155) 77)) \n(assert (= (tgt 155) 7)) \n \n;(assert (edge 156)) \n(assert (= (src 156) 78)) \n(assert (= (tgt 156) 3)) \n \n;(assert (edge 157)) \n(assert (= (src 157) 78)) \n(assert (= (tgt 157) 7)) \n \n;(assert (edge 158)) \n(assert (= (src 158) 79)) \n(assert (= (tgt 158) 5)) \n \n;(assert (edge 159)) \n(assert (= (src 159) 79)) \n(assert (= (tgt 159) 7)) \n \n;(assert (edge 160)) \n(assert (= (src 160) 80)) \n(assert (= (tgt 160) 7)) \n \n;(assert (edge 161)) \n(assert (= (src 161) 80)) \n(assert (= (tgt 161) 7)) \n \n;(assert (edge 162)) \n(assert (= (src 162) 81)) \n(assert (= (tgt 162) 13)) \n \n;(assert (edge 163)) \n(assert (= (src 163) 81)) \n(assert (= (tgt 163) 7)) \n \n;(assert (edge 164)) \n(assert (= (src 164) 82)) \n(assert (= (tgt 164) 15)) \n \n;(assert (edge 165)) \n(assert (= (src 165) 82)) \n(assert (= (tgt 165) 7)) \n \n;(assert (edge 166)) \n(assert (= (src 166) 83)) \n(assert (= (tgt 166) 22)) \n \n;(assert (edge 167)) \n(assert (= (src 167) 83)) \n(assert (= (tgt 167) 7)) \n \n;(assert (edge 168)) \n(assert (= (src 168) 84)) \n(assert (= (tgt 168) 1)) \n \n;(assert (edge 169)) \n(assert (= (src 169) 84)) \n(assert (= (tgt 169) 7)) \n \n\n;May End\n";
			final String smtlibMavoEncoding = smtlibEncoding + ";May formula\n\n(assert (or (and (edge 152)(edge 153)(node 68)(not (edge 154))(not (edge 155))(not (node 77))(not (edge 156))(not (edge 157))(not (node 78))(not (edge 158))(not (edge 159))(not (node 79))(not (edge 161))(not (edge 161))(not (node 80))(not (edge 162))(not (edge 163))(not (node 81))(not (edge 164))(not (edge 165))(not (node 82))(not (edge 166))(not (edge 167))(not (node 83))(not (edge 168))(not (edge 169))(not (node 84)))(and (not (edge 152))(not (edge 153))(not (node 68))(edge 154)(edge 155)(node 77)(not (edge 156))(not (edge 157))(not (node 78))(not (edge 158))(not (edge 159))(not (node 79))(not (edge 161))(not (edge 161))(not (node 80))(not (edge 162))(not (edge 163))(not (node 81))(not (edge 164))(not (edge 165))(not (node 82))(not (edge 166))(not (edge 167))(not (node 83))(not (edge 168))(not (edge 169))(not (node 84)))(and (not (edge 152))(not (edge 153))(not (node 68))(not (edge 154))(not (edge 155))(not (node 77))(edge 156)(edge 157)(node 78)(not (edge 158))(not (edge 159))(not (node 79))(not (edge 161))(not (edge 161))(not (node 80))(not (edge 162))(not (edge 163))(not (node 81))(not (edge 164))(not (edge 165))(not (node 82))(not (edge 166))(not (edge 167))(not (node 83))(not (edge 168))(not (edge 169))(not (node 84)))(and (not (edge 152))(not (edge 153))(not (node 68))(not (edge 154))(not (edge 155))(not (node 77))(not (edge 156))(not (edge 157))(not (node 78))(edge 158)(edge 159)(node 79)(not (edge 161))(not (edge 161))(not (node 80))(not (edge 162))(not (edge 163))(not (node 81))(not (edge 164))(not (edge 165))(not (node 82))(not (edge 166))(not (edge 167))(not (node 83))(not (edge 168))(not (edge 169))(not (node 84)))(and (not (edge 152))(not (edge 153))(not (node 68))(not (edge 154))(not (edge 155))(not (node 77))(not (edge 156))(not (edge 157))(not (node 78))(not (edge 158))(not (edge 159))(not (node 79))(edge 161)(edge 161)(node 80)(not (edge 162))(not (edge 163))(not (node 81))(not (edge 164))(not (edge 165))(not (node 82))(not (edge 166))(not (edge 167))(not (node 83))(not (edge 168))(not (edge 169))(not (node 84)))(and (not (edge 152))(not (edge 153))(not (node 68))(not (edge 154))(not (edge 155))(not (node 77))(not (edge 156))(not (edge 157))(not (node 78))(not (edge 158))(not (edge 159))(not (node 79))(not (edge 161))(not (edge 161))(not (node 80))(edge 162)(edge 163)(node 81)(not (edge 164))(not (edge 165))(not (node 82))(not (edge 166))(not (edge 167))(not (node 83))(not (edge 168))(not (edge 169))(not (node 84)))(and (not (edge 152))(not (edge 153))(not (node 68))(not (edge 154))(not (edge 155))(not (node 77))(not (edge 156))(not (edge 157))(not (node 78))(not (edge 158))(not (edge 159))(not (node 79))(not (edge 161))(not (edge 161))(not (node 80))(not (edge 162))(not (edge 163))(not (node 81))(edge 164)(edge 165)(node 82)(not (edge 166))(not (edge 167))(not (node 83))(not (edge 168))(not (edge 169))(not (node 84)))(and (not (edge 152))(not (edge 153))(not (node 68))(not (edge 154))(not (edge 155))(not (node 77))(not (edge 156))(not (edge 157))(not (node 78))(not (edge 158))(not (edge 159))(not (node 79))(not (edge 161))(not (edge 161))(not (node 80))(not (edge 162))(not (edge 163))(not (node 81))(not (edge 164))(not (edge 165))(not (node 82))(edge 166)(edge 167)(node 83)(not (edge 168))(not (edge 169))(not (node 84)))(and (not (edge 152))(not (edge 153))(not (node 68))(not (edge 154))(not (edge 155))(not (node 77))(not (edge 156))(not (edge 157))(not (node 78))(not (edge 158))(not (edge 159))(not (node 79))(not (edge 161))(not (edge 161))(not (node 80))(not (edge 162))(not (edge 163))(not (node 81))(not (edge 164))(not (edge 165))(not (node 82))(not (edge 166))(not (edge 167))(not (node 83))(edge 168)(edge 169)(node 84))))\n\n\n\n(assert (or (and (node 76)(node 66)(node 67)(node 68)(edge 55)(edge 148)(edge 149)(edge 150)(edge 151)(edge 56)(edge 57))(and (not (node 76))(not (node 66))(not (node 67))(not (node 68))(not (edge 55))(not (edge 148))(not (edge 149))(not (edge 150))(not (edge 151))(not (edge 56))(not (edge 57)))))\n";
			final String property = (propertyNum == 1) ?
				"(and (not (edge 168))(not (edge 169))(not (node 84)))" :
				"(and (node 26)(node 63))";
			final String mayElems = "(node 66)_(node 67)_(node 68)_(node 76)_(node 77)_(node 78)_(node 79)_(node 80)_(node 81)_(node 82)_(node 83)_(node 84)_(node 85)_(node 86)_(edge 54)_(edge 55)_(edge 56)_(edge 57)_(edge 148)_(edge 149)_(edge 150)_(edge 151)_(edge 152)_(edge 153)_(edge 154)_(edge 155)_(edge 156)_(edge 157)_(edge 158)_(edge 159)_(edge 160)_(edge 161)_(edge 162)_(edge 163)_(edge 164)_(edge 165)_(edge 166)_(edge 167)_(edge 168)_(edge 169)";
			Set<String> z3MayModelElems = new HashSet<String>();
			for (String mayElem : mayElems.split("_")) {
				z3MayModelElems.add(mayElem);
			}

		// run solver
		initOutput();
		System.setProperty("jna.library.path", LIBRARY_PATH);
		doMAVOPropertyCheck(smtlibMavoEncoding, property);
		if (timeClassicalEnabled || timeMAVOAllsatEnabled) {
			HashSet<String> smtlibConcretizations = doMAVOAllsatPropertyCheck(smtlibMavoEncoding, property, z3MayModelElems);
			if (timeClassicalEnabled) {
				doClassicalPropertyCheck(smtlibEncoding, property, smtlibConcretizations);
				speedupClassicalMAVO = ((double) timeClassical) / timeMAVO;
			}
		}
		if (isMAVOMaybe) {
			if (timeMAVOBackboneEnabled) {
				doMAVOBackbonePropertyCheck(smtlibMavoEncoding, property, z3MayModelElems);
			}
			if (timeMAVOBackboneEnabled && timeMAVOAllsatEnabled) {
				speedupMAVOAllsatMAVOBackbone = ((double) timeMAVOAllsat) / timeMAVOBackbone;
			}
		}

		// save execution times
		Properties outputProperties = new Properties();
		writeProperties(outputProperties);
		MultiModelOperatorUtils.writePropertiesFile(
			outputProperties,
			this,
			randommodelModel,
			MultiModelOperatorUtils.getSubdir(inputProperties),
			MultiModelOperatorUtils.OUTPUT_PROPERTIES_SUFFIX
		);

		return actualParameters;
	}

}
